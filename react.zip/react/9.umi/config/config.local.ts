



export default {
  define: {
    c:'local'
  }
   
}