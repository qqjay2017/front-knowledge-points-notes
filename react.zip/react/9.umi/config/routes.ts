export const routes =  [
  // {
  //   path: '/home',
  //   // redirect:'/home/user',
  //  component:'@/layouts/index',
  //   menu: {
  //     name: 'home', // 兼容此写法
  //   },
  //   routes:[
  //     // {
  //     //   path: '/home/user',  component: 'user',
  //     //   exact:true,
  //     //   menu: {
  //     //     name: 'user', // 兼容此写法
  //     //   },
  //     // },
  //     // {
  //     //   path: '/home/hhh',component: 'home',
  //     //   exact:true,
  //     //   menu: {
  //     //     name: 'hhh', // 兼容此写法
  //     //   },
  //     // }
  //   ]
  // },
  // {
  //   path: '/list', component: 'list',
  //   menu: {
  //     name: 'list1', // 兼容此写法
  //   },
  // },

]