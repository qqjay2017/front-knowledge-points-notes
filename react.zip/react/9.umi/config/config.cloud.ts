



export default {
  
    define: {
        b: 'cloud', c: 'cloud'
    }
 
}