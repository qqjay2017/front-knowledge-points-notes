 // 
 export default function(initialState) {
     console.log(initialState)
    const { menus } = initialState;
   
    return {
      canReadFoo: false,
     
    };
  }