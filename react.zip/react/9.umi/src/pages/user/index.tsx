import React from 'react';
import styles from './user.less';

export default () => {
  return (
    <div>
      <h1 className={styles.title}>Page user index</h1>
    </div>
  );
}
