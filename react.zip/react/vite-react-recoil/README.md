https://vitejs.dev/config/

```js
export default {
  esbuild: {
    jsxInject: `import React from 'react'`
  }
}
```
