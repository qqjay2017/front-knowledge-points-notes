
import  { Button } from 'antd'

const ButtonRender = ()=>{
    return <Button>按钮</Button>
}

const ButtonPreview = ()=>{
    return <Button>按钮</Button>
}

export default {
    ButtonRender,
    ButtonPreview
}
