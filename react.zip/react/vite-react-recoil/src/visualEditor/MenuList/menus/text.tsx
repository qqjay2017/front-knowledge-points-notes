const TextRender = ()=>{
    return <span>文本</span>
}

const TextPreview = ()=>{
    return <div>文本</div>
}

export default {
    TextRender,
    TextPreview
}
