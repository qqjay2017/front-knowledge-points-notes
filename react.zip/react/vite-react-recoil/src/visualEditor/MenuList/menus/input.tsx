
import  { Input } from 'antd'

const InputRender = ()=>{
    return <Input></Input>
}

const InputPreview = ()=>{
    return <Input></Input>
}

export default {
    InputRender,
    InputPreview
}
