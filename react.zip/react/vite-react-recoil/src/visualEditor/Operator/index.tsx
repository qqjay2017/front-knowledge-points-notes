import './index.scss'

const Operator = ()=>{
    return <div className="visual-editor-operator">Operator</div>
}

export default Operator
