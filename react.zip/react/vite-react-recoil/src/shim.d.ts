// enable types for import.meta.* and file types
import 'vite/env'