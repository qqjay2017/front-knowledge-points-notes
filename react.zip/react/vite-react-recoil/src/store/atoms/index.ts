import block from './block'

export default {
    block
}