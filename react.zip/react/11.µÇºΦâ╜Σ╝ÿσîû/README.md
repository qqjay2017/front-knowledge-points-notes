> https://github.com/brickspert/blog/issues/36

总结笔记

1. 这种由单个地方引起的性能问题，也是比较好解决的。找到它、修改它、解决它！
2. 浏览器Performance React profiler
3. memo useMemo useCallback
4. 谨慎使用 Context
5. 小心使用 Redux