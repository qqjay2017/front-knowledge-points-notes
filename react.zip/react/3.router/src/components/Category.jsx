function Category(){
    return <h1>Category</h1>
}

export default Category;