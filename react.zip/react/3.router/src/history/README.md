action: "POP"
block: ƒ block(prompt)
createHref: ƒ createHref(location)
go: ƒ go(n)
goBack: ƒ goBack()
goForward: ƒ goForward()
length: 4
listen: ƒ listen(listener)
location: {pathname: "/category", search: "", hash: "", state: undefined, key: "4l4g5s"}
push: ƒ push(path, state)
replace: ƒ replace(path, state)