import React from 'react'


import HomeButton from './HomeButton'

function Home(props){
   
   
    return <div>Home
        <HomeButton />
    </div>
}

export default Home