# DvaJS

> https://dvajs.com/guide/

```
dva 首先是一个基于 redux 和 redux-saga 的数据流方案，然后为了简化开发体验，dva 还额外内置了 react-router 和 fetch，所以也可以理解为一个轻量级的应用框架。
```

## 安装

`$ npm i dva  redux react-redux redux-saga react-router-dom connected-react-router`