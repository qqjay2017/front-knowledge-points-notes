



import React,{createContext} from 'react'

const ReduxContext = createContext({});
export default ReduxContext;