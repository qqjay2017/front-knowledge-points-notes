export const add1 = 'ADD1'
export const add2 = 'ADD2'


export const INCREMENT = "INCREMENT";
export const DECREMENT = "DECREMENT";