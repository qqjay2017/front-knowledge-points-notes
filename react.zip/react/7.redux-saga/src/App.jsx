import React from "react";
import SagaCounter from "./components/SagaCounter";

function App(props) {
  return <div>
     <SagaCounter />
  </div>;
}

export default App
