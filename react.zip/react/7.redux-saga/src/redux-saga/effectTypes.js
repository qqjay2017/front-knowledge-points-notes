export const TAKE = 'TAKE';
export const PUT = 'PUT';