
### 第 1 题：聊聊 Vue 的双向数据绑定，Model 如何改变 View，View 又是如何改变 Model 的



<br/>


### 第 2 题：Virtual DOM 真的比操作原生 DOM 快吗？谈谈你的想法。



<br/>



### 第 3 题：为什么 Vuex 的 mutation 和 Redux 的 reducer 中不能做异步操作？


<br/>



### 第 4 题：在 Vue 中，子组件为何不可以修改父组件传递的 Prop

如果修改了，Vue 是如何监控到属性的修改并给出警告的。



<br/>

### 第 5 题：双向绑定和 vuex 是否冲突



<br/>

### 第 7 题：Vue 的响应式原理中 Object.defineProperty 有什么缺陷？

为什么在 Vue3.0 采用了 Proxy，抛弃了 Object.defineProperty？


<br/>




### 第 8 题：如何设计实现无缝轮播



<br/>

### 第 9 题：Vue 的父组件和子组件生命周期钩子执行顺序是什么



<br/>


### 第 10 题：vue 在 v-for 时给每项元素绑定事件需要用事件代理吗？为什么？


<br/>


### 第 11 题：vue 渲染大量数据时应该怎么优化？




<br/>

### 第 12题：vue 如何优化首页的加载速度？vue 首页白屏是什么问题引起的？如何解决呢？

<br/>


### 第 13 题：vue 是如何对数组方法进行变异的？例如 push、pop、splice 等方法

劫持数组方法
数组的索引和长度变化是无法监控到的

[].__proto__ = 重写的方法

<br/>



###  第 14 题：谈一谈 nextTick 的原理


<br/>

### 第 15 题：Vue 中的 computed 和 watch 的区别在哪里（虾皮）

<br/>



### 第 16 题：v-if、v-show、v-html 的原理是什么，它是如何封装的？

<br/>


### 第 17 题： 谈谈你对MVC、MVP、MVVM？

<br/>



### 第 18题：fetch熟悉吗？axios拦截器如何实现的？axios如何取消请求？

<br/>



### 第 19题：new Vue(options)中发生了什么操作

<br/>


### 第 20 题：如果让你用proxy实现Vue的响应式系统，你会如何处理


<br/>

### 第 21 题： Vue 组件 data 为什么必须是函数


<br/>

### 第 22 题： React和Vue有什么区别


<br/>



### 第 23 题：  Vue生命周期的原理是什么



<br/>

### 第 24 题： 为什么要求组件模板只能有一个根元素



<br/>



### 第 25 题：为什么Vue中可以通过this访问到和修改this.$data的值



<br/>

### 第 26 题：在使用计算属性的时，函数名和data数据源中的数据可以同名吗



<br/>


### 第 26 题：keep-alive的实现原理和相关的生命周期



<br/>



### 第 27 题：Vue中diff算法key的作用



<br/>



### 第 28 题： vue变量名如果以_、$开头的属性会发生什么问题？怎么访问到它们的值？



<br/>


### 第 28 题：  说下$attrs和$listeners的使用场景




<br/>

### 第 29 题： Vue组件之间的通信


<br/>




### 第 30 题： 简述v-model的实现原理


<br/>


### 第 31 题： css scoped是如何在Vue中实现的


<br/>


### 第 32 题： nextTick为什么优先采用微任务


<br/>

### 第 33 题：complier 实现


<br/>
