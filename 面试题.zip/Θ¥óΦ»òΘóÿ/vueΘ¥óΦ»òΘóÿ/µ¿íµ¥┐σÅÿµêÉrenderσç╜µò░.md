1. template转成ast语法树
    1. 解析ast语法树
    2. 每个静态节点做标记,如果是静态,跳过diff
    3. render函数

parserHTML

2. 