编写复杂的 TypeScript 类型:
https://github.com/LeetCode-OpenSource/hire/blob/master/typescript_zh.md