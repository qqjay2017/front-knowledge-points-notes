function randomNumber(size = 16) {
    return parseInt(Math.random() * (10 ** size))
}

function strToRandomNumber(size = 16) {

}